﻿namespace ClinicaSonrrisaPlena.Models.Entities
{
    public class Administrador : Persona
    {
        public string RolDescripcion { get; set; }
    }
}
