﻿namespace ClinicaSonrrisaPlena.Models.Entities
{
    public class Recepcionista : Persona
    {
        public string Interno { get; set; }
    }
}
